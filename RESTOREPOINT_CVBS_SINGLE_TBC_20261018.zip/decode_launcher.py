#!/usr/bin/env python3
from __future__ import annotations

import argparse
import ctypes
import os
import shlex
import shutil
import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

# Ensure Qt platform plugins (xcb/cocoa/...) are discoverable inside
# PyInstaller onefile bundles (critical for Linux AppImage GUI launch).
# This must run BEFORE any PyQt6 import.
if getattr(sys, "frozen", False):
    _base = getattr(sys, "_MEIPASS", None) or os.path.dirname(sys.executable)
    if _base:
        for _rel in (
            os.path.join("PyQt6", "Qt6", "plugins"),
            os.path.join("PyQt6", "Qt", "plugins"),
            "plugins",
        ):
            _plug = os.path.join(_base, _rel)
            if os.path.isdir(os.path.join(_plug, "platforms")):
                os.environ.setdefault(
                    "QT_QPA_PLATFORM_PLUGIN_PATH", os.path.join(_plug, "platforms")
                )
                os.environ.setdefault("QT_PLUGIN_PATH", _plug)
                break


from decode_runtime import (
    MICROARCH_AUTO,
    MICROARCH_LEVELS,
    build_tape_decode_command,
    load_profiles,
    microarch_target_cpu,
    microarch_target_dir,
    native_host_arch,
    normalize_microarch_level,
    profile_is_composite,
    resolve_tape_decode_prefix,
)

try:
    from PyQt6.QtCore import QFileInfo, Qt, QTimer, QUrl, pyqtSignal
    from PyQt6.QtGui import QColor, QIcon, QPalette
    from PyQt6.QtWidgets import (
        QApplication,
        QCheckBox,
        QComboBox,
        QFileDialog,
        QFileIconProvider,
        QGridLayout,
        QGroupBox,
        QHBoxLayout,
        QLabel,
        QLineEdit,
        QMessageBox,
        QPushButton,
        QSpinBox,
        QStyleFactory,
        QVBoxLayout,
        QWidget,
    )
except ImportError as exc:
    raise SystemExit("PyQt6 is required for Decode Launcher.") from exc


ALIGN_TOP = Qt.AlignmentFlag.AlignTop


@dataclass(frozen=True)
class ToolSpec:
    label: str
    subcommand: str
    notes: str = ""


TOOLS = [
    ToolSpec(
        label="tape-decode decode (guided)",
        subcommand="decode",
        notes="Builds a decode command from the form fields and launches it in a terminal.",
    ),
    ToolSpec(
        label="tape-decode list-profiles (terminal)",
        subcommand="list-profiles",
        notes="Runs list-profiles; optional flags can be added in Extra arguments.",
    ),
    ToolSpec(
        label="tape-decode compare (terminal)",
        subcommand="compare",
        notes="Runs compare; provide required compare arguments in Extra arguments.",
    ),
    ToolSpec(
        label="tape-decode write-profile (terminal)",
        subcommand="write-profile",
        notes="Runs write-profile; provide required arguments in Extra arguments.",
    ),
]

INPUT_FORMATS = ["u8", "s8", "s16le", "u16le", "f32le", "flac"]
DEFAULT_PROFILE = "PAL_VHS"

# UI labels for the microarchitecture selector. Keep the first entry as the
# empty "Auto" choice so the QComboBox `currentIndex` 0 stays the safe default.
MICROARCH_UI_OPTIONS: tuple[tuple[str, str], ...] = (
    ("Auto (use host default)", MICROARCH_AUTO),
) + tuple((label, label) for label in MICROARCH_LEVELS)

WINDOWS_APP_USER_MODEL_ID = "harrypm.tape_decode_rust_gui.decode_launcher"

# Linux taskbar identity: must equal the AppImage's decode-rust-gui.desktop
# basename / Icon and its StartupWMClass (resources/appimage/).
LINUX_APP_IDENTITY = "decode-rust-gui"

def _default_mt_threads() -> int:
    """Return a high-side rounded default at ~80% of system logical threads."""
    system_threads = max(1, os.cpu_count() or 1)
    # Round up so we bias toward the higher nearby integer ("nearest high number").
    return max(1, (system_threads * 8 + 9) // 10)


def _split_user_args(extra_args: str, *, strict: bool = True) -> list[str]:
    if not extra_args.strip():
        return []
    try:
        parsed = shlex.split(extra_args, posix=os.name != "nt")
        if os.name == "nt":
            return [
                arg[1:-1]
                if len(arg) >= 2 and arg[0] == arg[-1] and arg[0] in {'"', "'"}
                else arg
                for arg in parsed
            ]
        return parsed
    except ValueError:
        if strict:
            raise
        return [extra_args]


def _arg_writes_raw_output_to_stdout(args: list[str]) -> bool:
    output_flags = {"--luma-out", "--chroma-out"}
    i = 0
    while i < len(args):
        token = args[i]
        if token in output_flags:
            if i + 1 < len(args) and args[i + 1] == "-":
                return True
            i += 2
            continue
        if any(token == f"{flag}=-" for flag in output_flags):
            return True
        i += 1
    return False


def _extract_dropped_file_path(mime_data, *, suffix_filter: Optional[set[str]] = None) -> Optional[str]:
    if mime_data is None:
        return None

    paths: list[str] = []
    if mime_data.hasUrls():
        for url in mime_data.urls():
            if not url.isLocalFile():
                continue
            local = url.toLocalFile().strip()
            if local:
                paths.append(local)
    elif mime_data.hasText():
        text = mime_data.text().strip()
        if text:
            local = QUrl(text).toLocalFile() if text.startswith("file:") else text
            if local:
                paths.append(local)

    for raw in paths:
        expanded = str(Path(raw).expanduser())
        if suffix_filter:
            suffix = Path(expanded).suffix.lower()
            if suffix not in suffix_filter:
                continue
        if Path(expanded).is_dir():
            continue
        return expanded
    return None


def _shell_join(parts: list[str]) -> str:
    return " ".join(shlex.quote(part) for part in parts)


def _shell_join_windows(parts: list[str]) -> str:
    return subprocess.list2cmdline(parts)


def _shell_join_platform(parts: list[str]) -> str:
    return _shell_join_windows(parts) if os.name == "nt" else _shell_join(parts)

def _set_windows_app_user_model_id() -> None:
    """Set a stable Windows AppUserModelID so taskbar/titlebar icon binding is reliable."""
    if os.name != "nt":
        return
    try:
        ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(
            WINDOWS_APP_USER_MODEL_ID
        )
    except Exception:
        pass

def _apply_linux_app_identity() -> None:
    """Pin the Qt window identity to ``decode-rust-gui`` on Linux.

    Desktop environments (Cinnamon/Mint, GNOME, KDE) tie a running window to
    its launcher/pinned icon through the X11 ``WM_CLASS`` or the Wayland
    ``app_id`` (desktop file name). Qt derives both from argv[0], which inside
    the AppImage is ``/tmp/.mount_XXXX/usr/bin/decode-rust-gui``, so the window
    matched no .desktop file: placeholder taskbar icon plus a stray
    ``Decode-Rust-Gui.cinnamon-generated.desktop``.

    Must run after the QApplication exists and before any window is shown
    (Qt reads the name when the native window is created). Never raises.
    """
    if not sys.platform.startswith("linux"):
        return
    try:
        from PyQt6.QtCore import QCoreApplication
        from PyQt6.QtGui import QGuiApplication

        # X11 WM_CLASS instance name; the class comes from applicationName.
        os.environ.setdefault("RESOURCE_NAME", LINUX_APP_IDENTITY)
        QCoreApplication.setApplicationName(LINUX_APP_IDENTITY)
        # Wayland app_id and the freedesktop desktop-file association.
        QGuiApplication.setDesktopFileName(LINUX_APP_IDENTITY)
    except Exception as exc:  # cosmetic only - never stop the GUI starting
        print(f"WARN: could not set application identity: {exc}", file=sys.stderr)


def _resolve_icon_path() -> Optional[Path]:
    """Find a suitable icon file for the window/taskbar icon.

    Works in source tree, onefile PyInstaller bundles (_MEIPASS), next to the
    executable, and inside AppImages (checks typical hicolor locations).
    """
    candidates: list[Path] = []

    # PyInstaller onefile bundle
    meipass = getattr(sys, "_MEIPASS", None)
    if meipass:
        mp = Path(meipass)
        if os.name == "nt":
            candidates.extend([
                mp / "resources" / "icon" / "tape-decode-rust.ico",
                mp / "tape-decode-rust.ico",
                mp / "decode-rust-gui.ico",
            ])
        candidates.extend([
            mp / "resources" / "icon" / "tape-decode-rust-256.png",
            mp / "tape-decode-rust-256.png",
            mp / "decode-rust-gui.png",
        ])

    # Next to the frozen executable (AppImage mount, extracted, or onefile dir)
    if getattr(sys, "frozen", False) or meipass:
        try:
            exe_dir = Path(sys.executable).resolve().parent
            if os.name == "nt":
                candidates.extend([
                    exe_dir / "resources" / "icon" / "tape-decode-rust.ico",
                    exe_dir / "tape-decode-rust.ico",
                    exe_dir / "decode-rust-gui.ico",
                ])
            candidates.extend([
                exe_dir / "resources" / "icon" / "tape-decode-rust-256.png",
                exe_dir / "tape-decode-rust-256.png",
                exe_dir / "decode-rust-gui.png",
            ])
            # AppImage mount layout: exe at <mount>/usr/bin/decode-rust-gui
            # hicolor and .DirIcon live at <mount>/usr/share/... and <mount>/.DirIcon
            mount_root = exe_dir.parent  # <mount>/usr
            candidates.append(mount_root / "share" / "icons" / "hicolor" / "256x256" / "apps" / "decode-rust-gui.png")
            candidates.append(mount_root.parent / "usr" / "share" / "icons" / "hicolor" / "256x256" / "apps" / "decode-rust-gui.png")
            # Walk up a few levels to find AppDir root or mount root (robustness)
            p = exe_dir
            for _ in range(6):
                candidates.append(p / "usr" / "share" / "icons" / "hicolor" / "256x256" / "apps" / "decode-rust-gui.png")
                candidates.append(p / ".DirIcon")
                candidates.append(p / "decode-rust-gui.png")
                if (p / ".DirIcon").exists() or (p / "usr" / "share").exists():
                    break
                p = p.parent
        except Exception:
            pass

    # Source tree (development)
    try:
        here = Path(__file__).resolve().parent
        if os.name == "nt":
            candidates.extend([
                here / "resources" / "icon" / "tape-decode-rust.ico",
                here.parent / "resources" / "icon" / "tape-decode-rust.ico",
                Path.cwd() / "resources" / "icon" / "tape-decode-rust.ico",
            ])
        candidates.extend([
            here / "resources" / "icon" / "tape-decode-rust-256.png",
            here.parent / "resources" / "icon" / "tape-decode-rust-256.png",
            Path.cwd() / "resources" / "icon" / "tape-decode-rust-256.png",
        ])
    except Exception:
        pass

    for c in candidates:
        try:
            if c and c.is_file():
                return c.resolve()
        except Exception:
            continue
    return None


def _open_linux_terminal(shell_command: str) -> None:
    shell = os.environ.get("SHELL", "/bin/bash")
    shell_args = [shell, "-lc", shell_command]
    terminal_candidates: list[tuple[str, list[str]]] = [
        ("x-terminal-emulator", ["x-terminal-emulator", "-e", *shell_args]),
        ("gnome-terminal", ["gnome-terminal", "--", *shell_args]),
        ("kgx", ["kgx", "--", *shell_args]),
        ("konsole", ["konsole", "-e", *shell_args]),
        ("mate-terminal", ["mate-terminal", "--", *shell_args]),
        ("xfce4-terminal", ["xfce4-terminal", "--command", f"{shell} -lc {shlex.quote(shell_command)}"]),
        ("lxterminal", ["lxterminal", "-e", f"{shell} -lc {shlex.quote(shell_command)}"]),
        ("kitty", ["kitty", "--hold", *shell_args]),
        ("alacritty", ["alacritty", "-e", *shell_args]),
        ("xterm", ["xterm", "-hold", "-e", *shell_args]),
    ]

    for binary, command in terminal_candidates:
        if shutil.which(binary):
            subprocess.Popen(command)
            return

    raise RuntimeError(
        "Could not find a supported Linux terminal emulator (e.g. gnome-terminal, konsole, xterm)."
    )


def _open_terminal(
    command_parts: list[str],
    working_directory: Path,
    *,
    env_exports: Optional[dict[str, str]] = None,
) -> None:
    if os.name == "nt":
        # On Windows, a fresh console doesn't inherit any env we set here
        # unless we mutate os.environ before Popen.
        prior: dict[str, Optional[str]] = {}
        if env_exports:
            for key, value in env_exports.items():
                prior[key] = os.environ.get(key)
                os.environ[key] = value
        try:
            creation_flags = getattr(subprocess, "CREATE_NEW_CONSOLE", 0)
            subprocess.Popen(
                command_parts,
                cwd=str(working_directory),
                creationflags=creation_flags,
            )
        finally:
            if env_exports:
                for key, original in prior.items():
                    if original is None:
                        os.environ.pop(key, None)
                    else:
                        os.environ[key] = original
        return

    env_prefix = ""
    if env_exports:
        exports = " ".join(
            f"{key}={shlex.quote(value)}" for key, value in env_exports.items()
        )
        env_prefix = f"{exports} "

    command = _shell_join(command_parts)
    shell = os.environ.get("SHELL", "/bin/bash")
    shell_command = (
        f'echo "[decode-launcher] starting command..."; '
        f"cd {shlex.quote(str(working_directory))} && {env_prefix}{command}; "
        "status=$?; "
        "echo; "
        'echo "[decode-launcher] process finished with exit code $status"; '
        f"exec {shlex.quote(shell)} -l"
    )

    if sys.platform == "darwin":
        escaped = shell_command.replace("\\", "\\\\").replace('"', '\\"')
        subprocess.Popen(
            [
                "osascript",
                "-e",
                'tell application "Terminal" to activate',
                "-e",
                f'tell application "Terminal" to do script "{escaped}"',
            ]
        )
        return

    _open_linux_terminal(shell_command)


class FileDropLineEdit(QLineEdit):
    fileDropped = pyqtSignal(str)

    def __init__(self, *, suffix_filter: Optional[set[str]] = None):
        super().__init__()
        self._suffix_filter = suffix_filter
        self.setAcceptDrops(True)

    def dragEnterEvent(self, event) -> None:
        dropped = _extract_dropped_file_path(
            event.mimeData(), suffix_filter=self._suffix_filter
        )
        if dropped:
            event.acceptProposedAction()
            return
        super().dragEnterEvent(event)

    def dragMoveEvent(self, event) -> None:
        dropped = _extract_dropped_file_path(
            event.mimeData(), suffix_filter=self._suffix_filter
        )
        if dropped:
            event.acceptProposedAction()
            return
        super().dragMoveEvent(event)

    def dropEvent(self, event) -> None:
        dropped = _extract_dropped_file_path(
            event.mimeData(), suffix_filter=self._suffix_filter
        )
        if dropped:
            self.setText(dropped)
            self.fileDropped.emit(dropped)
            event.acceptProposedAction()
            return
        super().dropEvent(event)


class DecodeLauncherWindow(QWidget):
    def __init__(self):
        super().__init__()
        self._tools = TOOLS
        self.setWindowTitle("Decode Launcher")
        self.resize(860, 360)

        self.tool_combo = QComboBox()
        for tool in self._tools:
            self.tool_combo.addItem(tool.label)
        self.tool_combo.setCurrentIndex(0)

        self.note_label = QLabel("")
        self.note_label.setWordWrap(True)

        self.input_edit = FileDropLineEdit()
        self.input_edit.setPlaceholderText("Drop RF input file here")
        self.input_browse_button = QPushButton("Input…")

        self.output_edit = QLineEdit("")
        self.output_browse_button = QPushButton("Output…")

        self.profile_combo = QComboBox()
        self.profile_combo.setEditable(True)
        self.profile_combo.addItem(DEFAULT_PROFILE)
        self.refresh_profiles_button = QPushButton("Refresh profiles")

        self.use_profile_file_check = QCheckBox("Use profile JSON file")
        self.profile_file_edit = FileDropLineEdit(suffix_filter={".json"})
        self.profile_file_edit.setPlaceholderText("Drop profile JSON file here")
        self.profile_file_browse_button = QPushButton("Profile JSON…")

        self.frequency_edit = QLineEdit("40")
        self.input_format_combo = QComboBox()
        self.input_format_combo.addItems(INPUT_FORMATS)
        self.input_format_combo.setCurrentText("flac")

        self.microarch_combo = QComboBox()
        for ui_label, _value in MICROARCH_UI_OPTIONS:
            self.microarch_combo.addItem(ui_label)
        self.microarch_combo.setCurrentIndex(0)
        self.microarch_locate_button = QPushButton("Locate binary")
        self.microarch_locate_button.setToolTip(
            "Show the on-disk path of the tape-decode binary that will be used\n"
            "for the selected x86-64 microarchitecture level."
        )
        non_x86 = native_host_arch() != "x86_64"
        if non_x86:
            self.microarch_combo.setEnabled(False)
            self.microarch_locate_button.setEnabled(False)
            self.microarch_combo.setToolTip(
                "x86-64 microarchitecture selection is only relevant on x86_64 hosts.\n"
                "On this host, compile from source with RUSTFLAGS=\"-C target-cpu=native\"."
            )

        self.threads_spin = QSpinBox()
        self.threads_spin.setRange(0, max(64, os.cpu_count() or 1))
        self.threads_spin.setValue(_default_mt_threads())
        self.mt_distance_size_spin = QSpinBox()
        self.mt_distance_size_spin.setRange(1, 1000000)
        self.mt_distance_size_spin.setValue(80)

        self.include_chroma_check = QCheckBox("Write chroma output (_chroma.tbc)")
        self.include_chroma_check.setChecked(True)
        self.include_metadata_check = QCheckBox("Write metadata output (.tbc.json)")
        self.include_metadata_check.setChecked(True)
        self.ire0_adjust_check = QCheckBox("Adjust RF IRE0 (--ire0-adjust)")
        self.ire0_adjust_check.setChecked(True)
        self.subdeemp_check = QCheckBox("Enable sub-deemphasis (--subdeemp)")
        self.subdeemp_check.setChecked(True)

        self.overwrite_check = QCheckBox("Allow overwrite (--overwrite)")
        self.debug_check = QCheckBox("Enable debug logging (--debug)")

        self.extra_args_edit = QLineEdit("")
        self.command_preview = QLineEdit("")
        self.command_preview.setReadOnly(True)

        self.launch_button = QPushButton("Launch selected tool")
        self.launch_tbc_tools_button = QPushButton("Launch tbc-tools / ld-analyse")
        self.close_button = QPushButton("Close")

        self._output_manually_set = False

        # Composite (CVBS) profile detection state: whether the currently
        # selected profile decodes the whole composite into the luma output
        # (single combined .tbc), the user's remembered chroma-checkbox choice
        # while a composite profile forces it off, and a debounce timer so
        # profile typing / profile-file edits do not run a subprocess per
        # keystroke.
        self._profile_composite: Optional[bool] = None
        self._chroma_user_checked: Optional[bool] = None
        self._composite_query_cache: dict[str, bool] = {}
        self._composite_check_timer = QTimer(self)
        self._composite_check_timer.setSingleShot(True)
        self._composite_check_timer.setInterval(250)
        self._composite_check_timer.timeout.connect(self._run_composite_check)

        self._build_layout()
        self._wire_events()
        self._refresh_tool_state()

        QTimer.singleShot(0, self._refresh_profiles)

    def _build_layout(self) -> None:
        root = QVBoxLayout()
        root.setAlignment(ALIGN_TOP)

        launch_group = QGroupBox("")
        launch_layout = QGridLayout()
        launch_group.setLayout(launch_layout)

        launch_layout.addWidget(QLabel("Tool"), 0, 0)
        launch_layout.addWidget(self.tool_combo, 0, 1, 1, 3)

        launch_layout.addWidget(QLabel("Input file"), 1, 0)
        launch_layout.addWidget(self.input_edit, 1, 1, 1, 2)
        launch_layout.addWidget(self.input_browse_button, 1, 3)

        launch_layout.addWidget(QLabel("Output base"), 2, 0)
        launch_layout.addWidget(self.output_edit, 2, 1, 1, 2)
        launch_layout.addWidget(self.output_browse_button, 2, 3)

        launch_layout.addWidget(QLabel("Profile"), 3, 0)
        launch_layout.addWidget(self.profile_combo, 3, 1, 1, 2)
        launch_layout.addWidget(self.refresh_profiles_button, 3, 3)

        launch_layout.addWidget(self.use_profile_file_check, 4, 0, 1, 4)

        launch_layout.addWidget(QLabel("Profile file"), 5, 0)
        launch_layout.addWidget(self.profile_file_edit, 5, 1, 1, 2)
        launch_layout.addWidget(self.profile_file_browse_button, 5, 3)

        launch_layout.addWidget(QLabel("Frequency (MHz)"), 6, 0)
        launch_layout.addWidget(self.frequency_edit, 6, 1)
        launch_layout.addWidget(QLabel("Input format"), 6, 2)
        launch_layout.addWidget(self.input_format_combo, 6, 3)

        launch_layout.addWidget(QLabel("Threads (0 = serial)"), 7, 0)
        launch_layout.addWidget(self.threads_spin, 7, 1)
        launch_layout.addWidget(QLabel("MT distance size"), 7, 2)
        launch_layout.addWidget(self.mt_distance_size_spin, 7, 3)

        launch_layout.addWidget(QLabel("x86-64 microarch level"), 8, 0)
        launch_layout.addWidget(self.microarch_combo, 8, 1, 1, 2)
        launch_layout.addWidget(self.microarch_locate_button, 8, 3)

        launch_layout.addWidget(self.include_chroma_check, 9, 0, 1, 2)
        launch_layout.addWidget(self.include_metadata_check, 10, 2, 1, 2)
        launch_layout.addWidget(self.overwrite_check, 11, 0, 1, 2)
        launch_layout.addWidget(self.ire0_adjust_check, 11, 2, 1, 2)
        launch_layout.addWidget(self.debug_check, 12, 0, 1, 2)
        launch_layout.addWidget(self.subdeemp_check, 12, 2, 1, 2)

        launch_layout.addWidget(QLabel("Extra arguments"), 13, 0)
        launch_layout.addWidget(self.extra_args_edit, 13, 1, 1, 3)

        launch_layout.addWidget(QLabel("Terminal preview"), 14, 0)
        launch_layout.addWidget(self.command_preview, 14, 1, 1, 3)

        launch_layout.addWidget(self.note_label, 15, 0, 1, 4)

        action_row = QHBoxLayout()
        action_row.addWidget(self.launch_button)
        action_row.addWidget(self.launch_tbc_tools_button)
        action_row.addWidget(self.close_button)

        root.addWidget(launch_group)
        root.addLayout(action_row)
        self.setLayout(root)

    def _wire_events(self) -> None:
        self.tool_combo.currentIndexChanged.connect(self._refresh_tool_state)
        self.input_edit.textChanged.connect(self._on_input_changed)
        self.output_edit.textChanged.connect(self._refresh_tool_state)
        self.output_edit.textEdited.connect(self._on_output_edited)
        self.profile_combo.currentTextChanged.connect(self._refresh_tool_state)
        self.use_profile_file_check.toggled.connect(self._refresh_tool_state)
        self.profile_file_edit.textChanged.connect(self._refresh_tool_state)
        # Composite (CVBS) profile detection: re-check whenever the profile
        # selection or profile-file path may have changed (debounced).
        self.profile_combo.currentTextChanged.connect(self._schedule_composite_check)
        self.use_profile_file_check.toggled.connect(self._schedule_composite_check)
        self.profile_file_edit.textChanged.connect(self._schedule_composite_check)
        self.frequency_edit.textChanged.connect(self._refresh_tool_state)
        self.input_format_combo.currentIndexChanged.connect(self._refresh_tool_state)
        self.threads_spin.valueChanged.connect(self._refresh_tool_state)
        self.mt_distance_size_spin.valueChanged.connect(self._refresh_tool_state)
        self.include_chroma_check.toggled.connect(self._refresh_tool_state)
        self.include_metadata_check.toggled.connect(self._refresh_tool_state)
        self.ire0_adjust_check.toggled.connect(self._refresh_tool_state)
        self.overwrite_check.toggled.connect(self._refresh_tool_state)
        self.debug_check.toggled.connect(self._refresh_tool_state)
        self.subdeemp_check.toggled.connect(self._refresh_tool_state)
        self.extra_args_edit.textChanged.connect(self._refresh_tool_state)

        self.refresh_profiles_button.clicked.connect(self._refresh_profiles)
        self.input_browse_button.clicked.connect(self._browse_input_file)
        self.output_browse_button.clicked.connect(self._browse_output_path)
        self.profile_file_browse_button.clicked.connect(self._browse_profile_file)
        self.microarch_combo.currentIndexChanged.connect(self._refresh_tool_state)
        self.microarch_locate_button.clicked.connect(self._locate_level_binary)
        self.launch_button.clicked.connect(self._launch_selected_tool)
        self.launch_tbc_tools_button.clicked.connect(self._launch_tbc_tools)
        self.close_button.clicked.connect(self.close)

    def _selected_tool(self) -> ToolSpec:
        return self._tools[self.tool_combo.currentIndex()]

    def _is_decode_tool(self) -> bool:
        return self._selected_tool().subcommand == "decode"

    def _refresh_profiles(self) -> None:
        current = self.profile_combo.currentText().strip()
        profiles = load_profiles()
        if not profiles:
            if self.profile_combo.count() == 0:
                self.profile_combo.addItem(DEFAULT_PROFILE)
            if not self.profile_combo.currentText().strip():
                self.profile_combo.setCurrentText(DEFAULT_PROFILE)
            self._refresh_tool_state()
            return

        self.profile_combo.blockSignals(True)
        self.profile_combo.clear()
        self.profile_combo.addItems(profiles)
        if current and current in profiles:
            self.profile_combo.setCurrentText(current)
        elif DEFAULT_PROFILE in profiles:
            self.profile_combo.setCurrentText(DEFAULT_PROFILE)
        elif profiles:
            self.profile_combo.setCurrentIndex(0)
        self.profile_combo.blockSignals(False)
        # addItems/setCurrentText ran with signals blocked, so the combo-change
        # wiring never fired: schedule the composite-profile check here.
        self._schedule_composite_check()
        self._refresh_tool_state()

    def _refresh_tool_state(self) -> None:
        tool = self._selected_tool()
        decode_selected = tool.subcommand == "decode"
        profile_file_selected = decode_selected and self.use_profile_file_check.isChecked()
        composite = decode_selected and self._profile_composite is True

        for widget in (
            self.input_edit,
            self.input_browse_button,
            self.output_edit,
            self.output_browse_button,
            self.frequency_edit,
            self.input_format_combo,
            self.threads_spin,
            self.mt_distance_size_spin,
            self.include_metadata_check,
            self.ire0_adjust_check,
            self.overwrite_check,
            self.debug_check,
            self.subdeemp_check,
            self.use_profile_file_check,
            self.refresh_profiles_button,
        ):
            widget.setEnabled(decode_selected)

        # The chroma checkbox is handled separately: composite (CVBS) profiles
        # such as SMPTE Type C and Quadruplex decode the whole composite into
        # the luma output (single combined .tbc), so a separate chroma output
        # does not apply to them.
        self._apply_chroma_check_state(decode_selected, composite)

        self.profile_combo.setEnabled(decode_selected and not profile_file_selected)
        self.profile_file_edit.setEnabled(profile_file_selected)
        self.profile_file_browse_button.setEnabled(profile_file_selected)

        self.command_preview.setText(self._terminal_preview_command(tool))
        note = tool.notes
        if composite:
            note += (
                "\nCVBS/composite profile: single combined .tbc output - the luma "
                ".tbc contains the full composite signal, so no separate "
                "_chroma.tbc is written."
            )
        self.note_label.setText(note)

    def _apply_chroma_check_state(self, decode_selected: bool, composite: bool) -> None:
        check = self.include_chroma_check
        if decode_selected and composite:
            # Remember the user's choice only when first forced off, so
            # switching back to a colour-under profile restores it.
            if self._chroma_user_checked is None:
                self._chroma_user_checked = check.isChecked()
            check.blockSignals(True)
            check.setChecked(False)
            check.blockSignals(False)
            check.setEnabled(False)
            check.setToolTip(
                "CVBS/composite profile (e.g. SMPTE Type C, Quadruplex): the\n"
                "luma .tbc contains the combined composite signal, so a single\n"
                ".tbc is written and there is no separate _chroma.tbc."
            )
        else:
            if self._chroma_user_checked is not None:
                check.blockSignals(True)
                check.setChecked(self._chroma_user_checked)
                check.blockSignals(False)
                self._chroma_user_checked = None
            check.setEnabled(decode_selected)
            check.setToolTip("")

    def _schedule_composite_check(self) -> None:
        """(Re)start the debounce timer for the composite-profile check."""
        self._composite_check_timer.start()

    def _composite_check_key(self) -> Optional[str]:
        """Selection key for the composite check: the active profile file path
        (profile-file mode) or the profile name (embedded profile mode)."""
        if self.use_profile_file_check.isChecked():
            path = self.profile_file_edit.text().strip()
            return f"file:{path}" if path else None
        name = self.profile_combo.currentText().strip()
        return f"profile:{name}" if name else None

    def _run_composite_check(self) -> None:
        """Resolve whether the current selection is a composite (CVBS) profile
        and refresh the tool state (chroma checkbox, preview, note)."""
        key = self._composite_check_key()
        if key is None:
            self._profile_composite = None
        else:
            cached = self._composite_query_cache.get(key)
            if cached is not None:
                self._profile_composite = cached
            else:
                try:
                    if key.startswith("file:"):
                        composite = profile_is_composite(
                            profile_file=key[len("file:") :], timeout_seconds=10
                        )
                    else:
                        composite = profile_is_composite(
                            profile=key[len("profile:") :], timeout_seconds=10
                        )
                except Exception:
                    composite = None
                self._profile_composite = composite
                if composite is not None and key.startswith("profile:"):
                    # Embedded profile names are immutable for the session;
                    # profile files can change on disk, so only names are cached.
                    self._composite_query_cache[key] = composite
        self._refresh_tool_state()

    def _infer_default_output_base(self, input_path: str) -> str:
        if not input_path.strip():
            return ""
        path = Path(input_path.strip()).expanduser()
        parent = path.parent if path.parent.as_posix() != "." else Path.cwd()
        stem = path.stem or path.name
        return str(parent / stem)

    def _on_input_changed(self, value: str) -> None:
        if not self._output_manually_set:
            self.output_edit.setText(self._infer_default_output_base(value))
        self._refresh_tool_state()

    def _on_output_edited(self, value: str) -> None:
        self._output_manually_set = bool(value.strip())

    def _derive_output_paths(self, output_base: str) -> tuple[str, str, str]:
        output_base = output_base.strip()
        if not output_base:
            return "", "", ""
        if output_base.lower().endswith(".tbc"):
            luma = output_base
            base = output_base[: -len(".tbc")]
        else:
            luma = f"{output_base}.tbc"
            base = output_base
        chroma = f"{base}_chroma.tbc"
        metadata = f"{base}.tbc.json"
        return luma, chroma, metadata

    def _build_decode_args(self, *, strict: bool) -> list[str]:
        args = ["decode"]
        input_path = self.input_edit.text().strip()
        output_base = self.output_edit.text().strip()
        luma_out, chroma_out, metadata_out = self._derive_output_paths(output_base)

        if strict:
            if not input_path:
                raise RuntimeError("Select an input file.")
            if not output_base:
                raise RuntimeError("Select an output base path.")

        if luma_out:
            args += ["--luma-out", luma_out]
        # Composite (CVBS) profiles write a single combined .tbc: no chroma
        # output even if the check state is somehow still set.
        if chroma_out and self.include_chroma_check.isChecked() and not self._profile_composite:
            args += ["--chroma-out", chroma_out]
        if metadata_out and self.include_metadata_check.isChecked():
            args += ["--metadata-out", metadata_out]

        frequency = self.frequency_edit.text().strip()
        if frequency:
            args += ["--frequency", frequency]

        input_format = self.input_format_combo.currentText().strip()
        if input_format:
            args += ["--input-format", input_format]

        threads = self.threads_spin.value()
        if threads > 0:
            args += ["--mt-threads", str(threads)]
            args += ["--mt-distance-size", str(self.mt_distance_size_spin.value())]

        if self.overwrite_check.isChecked():
            args.append("--overwrite")
        if self.ire0_adjust_check.isChecked():
            args.append("--ire0-adjust")
        if self.debug_check.isChecked():
            args.append("--debug")
        if self.subdeemp_check.isChecked():
            args.append("--subdeemp")

        if self.use_profile_file_check.isChecked():
            profile_file = self.profile_file_edit.text().strip()
            if strict and not profile_file:
                raise RuntimeError("Select a profile JSON file or disable profile file mode.")
            if profile_file:
                args += ["--profile-file", profile_file]
        else:
            profile = self.profile_combo.currentText().strip()
            if strict and not profile:
                raise RuntimeError("Select a profile.")
            if profile:
                args += ["--profile", profile]

        extra = self.extra_args_edit.text().strip()
        if extra:
            extra_args = _split_user_args(extra, strict=strict)
            if _arg_writes_raw_output_to_stdout(extra_args):
                raise RuntimeError(
                    "Decode Launcher cannot use --luma-out - / --chroma-out - in Extra arguments. "
                    "Use Output base file paths in the form, or run a manual shell pipeline outside launcher."
                )
            args += extra_args

        if input_path:
            args.append(input_path)

        return args

    def _selected_microarch_level(self) -> str:
        """Return the normalized level for the currently-selected combo entry,
        or MICROARCH_AUTO for index 0."""
        index = self.microarch_combo.currentIndex()
        if 0 <= index < len(MICROARCH_UI_OPTIONS):
            return normalize_microarch_level(MICROARCH_UI_OPTIONS[index][1])
        return MICROARCH_AUTO

    def _build_command(self, tool: ToolSpec, *, strict: bool) -> list[str]:
        level = self._selected_microarch_level()
        if tool.subcommand == "decode":
            return build_tape_decode_command(
                self._build_decode_args(strict=strict), level=level
            )

        extra = self.extra_args_edit.text().strip()
        extra_args = _split_user_args(extra, strict=strict) if extra else []
        return build_tape_decode_command(
            [tool.subcommand] + extra_args, level=level
        )

    def _terminal_preview_command(self, tool: ToolSpec) -> str:
        level = self._selected_microarch_level()
        try:
            command = self._build_command(tool, strict=False)
            joined = _shell_join_platform(command)
        except Exception as exc:
            preview = f"[preview unavailable] {exc}"
        else:
            suffix_parts = []
            if level:
                try:
                    resolved = resolve_tape_decode_prefix(level=level)
                    if resolved:
                        suffix_parts.append(f"bin: {resolved[0]}")
                except FileNotFoundError:
                    suffix_parts.append(
                        f"binary for {level} not built"
                    )
            if level:
                suffix_parts.append(
                    f"RUSTFLAGS=-C target-cpu={microarch_target_cpu(level)}"
                )
                target_dir = microarch_target_dir(level)
                if target_dir:
                    suffix_parts.append(f"CARGO_TARGET_DIR={target_dir}")
            preview = joined
            if suffix_parts:
                preview = f"{joined}    [{'  '.join(suffix_parts)}]"
        return preview

    def _effective_working_directory(self) -> Path:
        input_path = self.input_edit.text().strip()
        if input_path:
            candidate = Path(input_path).expanduser()
            parent = candidate.parent
            if parent.is_dir():
                return parent.resolve()
        return Path(os.getcwd()).resolve()

    def _browse_input_file(self) -> None:
        selected, _ = QFileDialog.getOpenFileName(
            self,
            "Select input RF file",
            self.input_edit.text().strip() or str(self._effective_working_directory()),
            "RF captures (*.flac *.lds *.u8 *.s8 *.s16le *.u16le *.f32le *.raw *.bin);;All files (*)",
        )
        if selected:
            self.input_edit.setText(selected)

    def _browse_output_path(self) -> None:
        selected, _ = QFileDialog.getSaveFileName(
            self,
            "Select output base name",
            self.output_edit.text().strip() or str(self._effective_working_directory()),
        )
        if selected:
            self._output_manually_set = True
            self.output_edit.setText(selected)

    def _browse_profile_file(self) -> None:
        selected, _ = QFileDialog.getOpenFileName(
            self,
            "Select profile JSON file",
            self.profile_file_edit.text().strip() or str(self._effective_working_directory()),
            "JSON files (*.json);;All files (*)",
        )
        if selected:
            self.profile_file_edit.setText(selected)

    def _output_to_tbc_candidate(self, output_value: str) -> Optional[Path]:
        if not output_value.strip():
            return None

        output_path = Path(output_value.strip()).expanduser()
        if not output_path.is_absolute():
            output_path = self._effective_working_directory() / output_path
        output_path = output_path.resolve(strict=False)

        if output_path.suffix.lower() in {".tbc", ".lds"}:
            return output_path
        return Path(str(output_path) + ".tbc")

    def _candidate_tbc_path(self) -> Optional[Path]:
        tbc_path = self._output_to_tbc_candidate(self.output_edit.text())
        if tbc_path is None:
            return None
        if tbc_path.exists():
            return tbc_path
        if self._is_decode_tool():
            return tbc_path
        return None

    def _candidate_tbc_tool_names(self) -> list[str]:
        if os.name == "nt":
            return ["ld-analyse.exe", "tbc-analyse.exe", "tbc-tools.exe"]
        if sys.platform == "darwin":
            return ["ld-analyse", "tbc-analyse", "tbc-tools"]
        return [
            "ld-analyse",
            "tbc-analyse",
            "tbc-tools",
            "tbc-tools.AppImage",
            "tbc-tools.appimage",
            "tbc-tools-x86_64.AppImage",
            "tbc-tools-x86_64.appimage",
            "tbc-tools-aarch64.AppImage",
            "tbc-tools-aarch64.appimage",
        ]

    def _existing_parent_dir(self, raw_path: str) -> Optional[Path]:
        if not raw_path.strip():
            return None
        candidate = Path(raw_path.strip()).expanduser()
        parent = candidate.parent
        if parent.is_dir():
            return parent.resolve()
        return None

    def _candidate_tbc_search_roots(self) -> list[Path]:
        roots: list[Path] = [self._effective_working_directory()]
        input_parent = self._existing_parent_dir(self.input_edit.text())
        output_parent = self._existing_parent_dir(self.output_edit.text())
        if input_parent is not None:
            roots.append(input_parent)
        if output_parent is not None:
            roots.append(output_parent)

        if os.name == "nt":
            roots.extend(
                [
                    Path(os.environ.get("ProgramFiles", r"C:\Program Files")),
                    Path(os.environ.get("ProgramFiles(x86)", r"C:\Program Files (x86)")),
                    Path.home() / "AppData" / "Local" / "Programs",
                ]
            )
        elif sys.platform == "darwin":
            roots.extend(
                [
                    Path("/Applications"),
                    Path.home() / "Applications",
                    Path("/opt/homebrew/bin"),
                    Path("/usr/local/bin"),
                    Path("/usr/bin"),
                ]
            )
        else:
            roots.extend(
                [
                    Path("/usr/local/bin"),
                    Path("/usr/bin"),
                    Path("/opt"),
                    Path.home() / "Applications",
                    Path.home() / "bin",
                ]
            )

        deduped: list[Path] = []
        seen: set[str] = set()
        for root in roots:
            key = str(root.resolve(strict=False))
            if key in seen:
                continue
            seen.add(key)
            deduped.append(root)
        return deduped

    def _find_tbc_tools_executable(self) -> Optional[Path]:
        names = self._candidate_tbc_tool_names()

        for name in names:
            on_path = shutil.which(name)
            if on_path:
                return Path(on_path)

        for root in self._candidate_tbc_search_roots():
            for name in names:
                direct = root / name
                if direct.is_file():
                    return direct

                in_tbc_tools_dir = root / "tbc-tools" / name
                if in_tbc_tools_dir.is_file():
                    return in_tbc_tools_dir

            if sys.platform == "darwin":
                mac_candidates = [
                    root / "tbc-tools.app" / "Contents" / "MacOS" / "ld-analyse",
                    root / "tbc-tools.app" / "Contents" / "MacOS" / "tbc-tools",
                    root / "ld-analyse.app" / "Contents" / "MacOS" / "ld-analyse",
                ]
                for candidate in mac_candidates:
                    if candidate.is_file():
                        return candidate

        return None

    def _macos_app_bundle_for_binary(self, executable: Path) -> Optional[Path]:
        if sys.platform != "darwin":
            return None
        for parent in executable.resolve(strict=False).parents:
            if parent.suffix.lower() == ".app":
                return parent
        return None

    def _locate_level_binary(self) -> None:
        level = self._selected_microarch_level()
        try:
            prefix = resolve_tape_decode_prefix(level=level)
        except FileNotFoundError as exc:
            QMessageBox.information(
                self,
                "Binary location",
                f"No tape-decode binary found for level {level or 'Auto'}.\n\n"
                f"{exc}\n\n"
                "Use the x86-64 microarch level selector to pick Auto, or build the binary for the chosen level outside the launcher.",
            )
            return
        path = prefix[0] if prefix else ""
        if not path:
            QMessageBox.information(self, "Binary location", "No binary resolved.")
            return
        QMessageBox.information(
            self,
            "Binary location",
            f"Level: {level or 'Auto'}\nBinary: {path}",
        )

    def _launch_tbc_tools(self) -> None:
        executable = self._find_tbc_tools_executable()
        if executable is None:
            QMessageBox.critical(
                self,
                "tbc-tools not found",
                "Could not find tbc-tools / ld-analyse in PATH or standard install locations.",
            )
            return

        tbc_candidate = self._candidate_tbc_path()
        app_bundle = self._macos_app_bundle_for_binary(executable)
        if app_bundle is not None:
            command = ["open", "-a", str(app_bundle)]
            if tbc_candidate is not None:
                command += ["--args", str(tbc_candidate)]
        else:
            command = [str(executable)]
            if tbc_candidate is not None:
                command.append(str(tbc_candidate))

        try:
            subprocess.Popen(command, cwd=str(self._effective_working_directory()))
        except Exception as exc:
            QMessageBox.critical(self, "Launch failed", str(exc))

    def _selected_microarch_env(self) -> Optional[dict[str, str]]:
        """Return env exports for the selected level, or None on Auto."""
        level = self._selected_microarch_level()
        if not level:
            return None
        env: dict[str, str] = {
            "RUSTFLAGS": f"-C target-cpu={microarch_target_cpu(level)}",
        }
        target_dir = microarch_target_dir(level)
        if target_dir:
            env["CARGO_TARGET_DIR"] = target_dir
        return env

    def _launch_selected_tool(self) -> None:
        tool = self._selected_tool()
        working_directory = self._effective_working_directory()
        if not working_directory.is_dir():
            QMessageBox.critical(
                self,
                "Invalid working directory",
                f"Directory does not exist:\n{working_directory}",
            )
            return

        try:
            command = self._build_command(tool, strict=True)
        except Exception as exc:
            QMessageBox.critical(self, "Invalid arguments", str(exc))
            return

        try:
            _open_terminal(
                command,
                working_directory,
                env_exports=self._selected_microarch_env(),
            )
        except Exception as exc:
            QMessageBox.critical(self, "Launch failed", str(exc))


def _apply_fusion_dark_mode(app: QApplication) -> None:
    fusion_style = QStyleFactory.create("Fusion")
    if fusion_style is not None:
        app.setStyle(fusion_style)
    else:
        app.setStyle("Fusion")

    role = QPalette.ColorRole if hasattr(QPalette, "ColorRole") else QPalette
    group = QPalette.ColorGroup if hasattr(QPalette, "ColorGroup") else QPalette

    palette = QPalette()
    palette.setColor(role.Window, QColor(53, 53, 53))
    palette.setColor(role.WindowText, QColor(225, 225, 225))
    palette.setColor(role.Base, QColor(35, 35, 35))
    palette.setColor(role.AlternateBase, QColor(53, 53, 53))
    palette.setColor(role.ToolTipBase, QColor(30, 30, 30))
    palette.setColor(role.ToolTipText, QColor(225, 225, 225))
    palette.setColor(role.Text, QColor(225, 225, 225))
    palette.setColor(role.Button, QColor(53, 53, 53))
    palette.setColor(role.ButtonText, QColor(225, 225, 225))
    palette.setColor(role.BrightText, QColor(255, 80, 80))
    palette.setColor(role.Highlight, QColor(42, 130, 218))
    palette.setColor(role.HighlightedText, QColor(20, 20, 20))
    palette.setColor(group.Disabled, role.Text, QColor(120, 120, 120))
    palette.setColor(group.Disabled, role.ButtonText, QColor(120, 120, 120))
    palette.setColor(group.Disabled, role.WindowText, QColor(120, 120, 120))
    app.setPalette(palette)
    app.setStyleSheet(
        "QToolTip { color: #e1e1e1; background-color: #2b2b2b; border: 1px solid #4a4a4a; }"
    )


def main(argv: Optional[list[str]] = None) -> int:
    parser = argparse.ArgumentParser(
        description="Decode Launcher (Qt) for running tape-decode commands"
    )
    parser.parse_args(argv)
    _set_windows_app_user_model_id()

    app = QApplication(sys.argv)
    _apply_linux_app_identity()
    _apply_fusion_dark_mode(app)
    window = DecodeLauncherWindow()

    # Set window + app icon for taskbar/dock/titlebar on all platforms.
    # This is especially important for Linux AppImage/taskbar integration.
    icon: Optional[QIcon] = None
    if os.name == "nt" and getattr(sys, "frozen", False):
        # Use the icon embedded in the .exe's PE resource section. QIcon(exe)
        # does NOT read PE-embedded icons (Qt's QIcon(path) loads image files,
        # not PE resources), so use QFileIconProvider, which resolves the shell
        # icon for the executable = the embedded PE icon. Verified to return a
        # non-null, multi-size icon for executables with embedded icons
        # (e.g. cmd.exe); falls back to the bundled .ico below otherwise.
        try:
            embedded_icon = QFileIconProvider().icon(QFileInfo(sys.executable))
            if not embedded_icon.isNull() and embedded_icon.availableSizes():
                icon = embedded_icon
        except Exception:
            pass
    if icon is None:
        icon_path = _resolve_icon_path()
        if icon_path:
            try:
                candidate_icon = QIcon(str(icon_path))
                if not candidate_icon.isNull():
                    icon = candidate_icon
            except Exception:
                pass
    if icon is not None:
        try:
            app.setWindowIcon(icon)
            window.setWindowIcon(icon)
        except Exception:
            pass

    window.show()
    return app.exec()


if __name__ == "__main__":
    raise SystemExit(main())
