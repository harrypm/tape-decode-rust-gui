#!/usr/bin/env python3
from __future__ import annotations

import os
from pathlib import Path

import PyInstaller.__main__

os.environ.setdefault("SETUPTOOLS_RUST_CARGO_PROFILE", "release")


_LEVELS: tuple[str, ...] = ("x86-64-v1", "x86-64-v2", "x86-64-v3", "x86-64-v4")
# Triples we may produce level builds for on Windows CI
_TRIPLES: tuple[str, ...] = ("x86_64-pc-windows-msvc", "aarch64-pc-windows-msvc")


def _binary_name() -> str:
    return "tape-decode.exe" if os.name == "nt" else "tape-decode"


def _platform_sep() -> str:
    return ";" if os.name == "nt" else ":"


def _resolve_tape_decode_bin() -> Path:
    explicit = os.environ.get("TAPE_DECODE_BIN", "").strip()
    if explicit:
        p = Path(explicit)
        if p.is_file():
            return p.resolve()
    bin_name = _binary_name()
    repo_root = Path.cwd()
    # Prefer a level build (lowest first = v1) as the default root binary.
    # This ensures the bare "." binary inside the bundle is always runnable
    # on any x86-64 host (CI verification and end-users on older CPUs).
    for lvl in _LEVELS:
        for tri in _TRIPLES:
            p = repo_root / f"target-{lvl}" / tri / "release" / bin_name
            if p.is_file():
                return p.resolve()
    # Legacy single-build locations and generic target/
    candidates = [
        Path(r"target\x86_64-pc-windows-msvc\release\tape-decode.exe"),
        Path(r"target\aarch64-pc-windows-msvc\release\tape-decode.exe"),
        Path(r"target\release\tape-decode.exe"),
    ]
    for candidate in candidates:
        if candidate and candidate.is_file():
            return candidate.resolve()
    raise FileNotFoundError(
        "Could not find tape-decode.exe. Build it before running this packaging script."
    )


def _discover_level_binaries() -> list[tuple[Path, str]]:
    """Find per-level optimized binaries laid out as target-x86-64-vN/<triple>/release/...

    Returns (src_path, dest_rel) suitable for --add-binary.
    """
    bin_name = _binary_name()
    repo_root = Path.cwd()
    results: list[tuple[Path, str]] = []
    for lvl in _LEVELS:
        for tri in _TRIPLES:
            p = repo_root / f"target-{lvl}" / tri / "release" / bin_name
            if p.is_file():
                dest = f"target-{lvl}/{tri}/release/{bin_name}"
                results.append((p.resolve(), dest))
                break
    return results


def main() -> None:
    tape_decode_bin = _resolve_tape_decode_bin()
    print(f"Bundling default {tape_decode_bin}")

    pyi_args: list[str] = [
        "decode.py",
        "--collect-all",
        "PyQt6",
        "--collect-all",
        "PyQt6-Qt6",
        "--collect-all",
        "PyQt6-sip",
        "--hidden-import",
        "decode_launcher",
        "--hidden-import",
        "decode_runtime",
        "--hidden-import",
        "decode_selftest",
        "--add-binary",
        f"{tape_decode_bin};.",
        "--add-data",
        f"crates\\tape-decode-cli\\src\\profiles\\profiles.json;.",
        # Bundle icon PNG so _resolve_icon_path / setWindowIcon can find it inside onefile for taskbar
        "--add-data",
        f"resources\\icon\\tape-decode-rust-256.png;resources\\icon\\tape-decode-rust-256.png",
        "--add-data",
        f"resources\\icon\\tape-decode-rust-256.png;tape-decode-rust-256.png",
        "--add-data",
        f"resources\\icon\\tape-decode-rust-256.png;decode-rust-gui.png",
        # Bundle ICO too so Windows can use native multi-size icon fallback at runtime.
        "--add-data",
        f"resources\\icon\\tape-decode-rust.ico;resources\\icon\\tape-decode-rust.ico",
        "--add-data",
        f"resources\\icon\\tape-decode-rust.ico;tape-decode-rust.ico",
        "--add-data",
        f"resources\\icon\\tape-decode-rust.ico;decode-rust-gui.ico",
        "--icon",
        "resources\\icon\\tape-decode-rust.ico",
        "--onefile",
        "-y",
        "--clean",
        "--name",
        "decode-rust-gui",
    ]

    # Explicitly ensure Qt platform plugins (qwindows.dll etc.) and the Qt6
    # runtime DLLs are inside the bundle so Qt can initialize on a clean
    # Windows host with no Python/Qt installed. Mirrors the macOS/Linux
    # packaging scripts (build-macos/linux-decode-bin.py).
    try:
        import PyQt6  # type: ignore
        qt_root = os.path.join(os.path.dirname(PyQt6.__file__), "Qt6")
        plugins_dir = os.path.join(qt_root, "plugins")
        if os.path.isdir(plugins_dir):
            pyi_args += ["--add-data", f"{plugins_dir}{_platform_sep()}PyQt6/Qt6/plugins"]
            print(f"Adding Qt plugins from {plugins_dir}")
    except Exception as exc:
        print(f"Could not locate PyQt6 Qt plugins for collection: {exc}")

    for src, dest in _discover_level_binaries():
        print(f"Bundling level binary {src} -> {dest}")
        pyi_args += ["--add-binary", f"{src};{dest}"]

    PyInstaller.__main__.run(pyi_args)


if __name__ == "__main__":
    main()
